﻿using static System.Console;
using System;
using System.Windows.Forms;


namespace HeadFirst.CSharp.Leftover2
{
    public interface IAboutGuy
    {
        string Name { get; }
        int Age { get; }
        int Cash { get; }
    }


    internal class Guy : IAboutGuy
    {

        #region About Guy

        private readonly string name;
        private readonly int age, cash;

        public string Name { get { return name; } }
        public int Age { get { return age; } }
        public int Cash { get { return cash; } }

        public override string ToString()
        {
            return $"The {typeof(Guy).Name} {Name} is {Age} years and has {Cash:C} in his wallet.";
        }

        public Guy(string name, int age, int cash)
        {
            this.name = name;
            this.age = age;
            this.cash = cash;
        }
        #endregion
    }




    public class Writer
    {
        #region About Writer

        protected internal int Protected_Internal_ID { get; set; }
        protected int ID { get; set; }

        protected internal string BookWritten { get; }
        public string WriterName { get; }

        public override string ToString()
        {
            return $"{typeof(Writer).Name}: {WriterName} -- \"{BookWritten}\" -- " +
                   $"protected internal int ID: {Protected_Internal_ID} -- " +
                   $"protected int ID: {ID}.";

        }


        public Writer(string bookWritten, string name)
        {
            BookWritten = bookWritten;
            WriterName = name;
            Protected_Internal_ID = 1;
            ID = 1;

        }
        #endregion
    }

    public class HiThereWriter : Writer
    {

        private Guy AboutGuy()
        {
            return new Guy("Adrian", DateTime.Now.Year - 1985, 2001);
        }

        public IAboutGuy DoSomething()
        {
            return AboutGuy();
        }


        public void AboutGuy(IAboutGuy aboutGuy)
        {
            WriteLine(aboutGuy);
        }

        public static void HiThere(string name)
        {
            MessageBox.Show($"Hi there! My name is {name}");
        }

        public int ChangeProtectedInternalID(Writer writer)
        {
            /*with protected internal it can change any Writer instance via a qualifier of type Writer.*/
            return writer.Protected_Internal_ID = new Random().Next(1, 100);
            
        }

        public int ChangeID(Writer writer)
        {
            /*with only protected changes only the caller of the method.*/
            return ID = new Random().Next(1, 100);
        }

        public override string ToString()
        {
            return $"{typeof(HiThereWriter).Name}: {WriterName} -- \"{BookWritten}\" -- " +
                   $"protected internal int ID: {Protected_Internal_ID} -- " +
                   $"protected int ID: {ID}.";
        }

        public HiThereWriter(string bookWritten, string name)
            : base(bookWritten, name) { }
    }

    public class LineWriter
    {
        public static void WriteALine(string message)
        {
            WriteLine(message);
        }

        public void ChangeWriterProtIntID(Writer writer)
        {
            writer.Protected_Internal_ID = new Random().Next(1, 1000); /*with protected internal it can change any Writer instance.*/
            //  WriteLine(writer.BookWritten); /*with only protected do not have access to ID*/
        }
    }
}

namespace PainterNamespace
{
    public class Painter
    {
        #region About Writer
    
        private protected int ID { get; set; }

        protected internal string PaintWork{ get; }
        public string PainterName { get; }

        public override string ToString()
        {
            return $"{typeof(Painter).Name}: {PainterName} -- \"{PaintWork}\" -- {ID}.";
        }


        public Painter(string paintWork, string painterName)
        {
            PaintWork = paintWork;
            PainterName = painterName;
            ID = 1;

        }
        #endregion
    }

    public class HiTherePainter : Painter
    {

        public static void HiThere(string name)
        {
            MessageBox.Show($"Hi there! My name is {name}");
        }

        public int ChangeID(Painter painter)
        {
            return ID = 49;
        }

        public override string ToString()
        {
            return $"{typeof(HiTherePainter).Name}: {PainterName} -- \"{PaintWork}\" -- {ID}.";
        }

        public HiTherePainter(string paintWork, string painterName)
            : base(paintWork, painterName) { }
    }

    internal class LinePainter
    {
        public void GetLinePainter(Painter painter)
        {
            /*Can not access the ID property via a Painter type because is protected.*/
            //painter.ID = 222;
            /*In order to access the ID property the LinePainter has to inherit from Painter.*/
            //ID = 222;
            WriteLine(painter.PaintWork);
        }
    }
}