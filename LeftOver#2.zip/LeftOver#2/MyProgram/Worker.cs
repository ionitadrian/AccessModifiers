﻿using HeadFirst.CSharp.Leftover2;


namespace MyProgram
{
    internal class Worker : IAboutGuy
    {
        public string Name { get; }
        public int Age { get; }
        public int Cash { get; }

        public override string ToString()
        {
            return $"{Name} - {Age} - {Cash}";
        }

        public Worker(string name, int age, int cash)
        {
            Name = name;
            Age = age;
            Cash = cash;
        }
    }
}

