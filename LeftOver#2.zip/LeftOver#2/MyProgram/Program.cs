﻿using static System.Console;
using static System.Environment;
using System;
using HeadFirst.CSharp.Leftover2;
using PainterNamespace;



namespace MyProgram
{



    internal class Program
    {


        private static void Main()
        {

            Writer writer = new Writer("Think and Grow Rich", "Napoleon Hill");
            HiThereWriter hiThere = new HiThereWriter("12 Rules of Life", "Jordan Peterson");


            #region Using ReadLine() method

            StartAccessModifiersApp();


            while (true)
            {
                string argumentToPass = ReadLine();
                CheckForArguments(argumentToPass, writer, hiThere);
            }

            #endregion




            #region Using ReadKey() method

            //List<char> CharList = new List<char>();

            //Clear();
            //ShowArgumentDescription();

            //while (true)
            //{

            //    string argumentToProvide = null;
            //    ForegroundColor = ConsoleColor.Green;
            //    CharList.Add(ReadKey().KeyChar);


            //    CheckBackspaceIsPressed(CharList, argumentToProvide, writer, hiThere);
            //    CheckEnterIsPressed(CharList, argumentToProvide, writer, hiThere);

            //}

            #endregion
        }


        private static void CheckForArguments(string argumentToCheck, Writer writer, HiThereWriter hiThere)
        {

            switch (argumentToCheck)
            {
                case "p": ExplainProtected(writer, hiThere); break;
                case "pi": ExplainProtectedInternal(writer, hiThere); WriteLine(); break;
                case "pp": ExplainPrivateProtected(); break;
                case "exit": WriteLine($"{typeof(Program).Name} closed."); Exit(0); break;
                case "clear": Clear(); ShowArgumentDescription(); break;
                case "help": StartAccessModifiersApp(); break;
                default:
                    ForegroundColor = ConsoleColor.Red;
                    WriteLine($"Please provide \"p\", \"pi\", \"pp\" or \"exit\" !!!");
                    ResetColor();
                    break;
            }
        }

        #region Using ReadKey() method

        /// <summary>
        /// Checks if Backspace key \b is pressed.
        /// </summary>
        //private static void CheckBackspaceIsPressed(List<char> CharBackspaceList, string argumentToPass,
        //                                            Writer writer, HiThereWriter hiThere)
        //{

        //    if (CharBackspaceList.Contains('\b'))
        //    {
        //        CharBackspaceList.Remove('\b');
        //        if (CharBackspaceList.Count == 0)
        //        {
        //            ResetColor();
        //            WriteLine($"{typeof(Program).Name} will exit. ");
        //            Exit(0);
        //        }
        //        else
        //        {
        //            CharBackspaceList.RemoveAt(CharBackspaceList.Count - 1);
        //            for (int c = 0; c < CharBackspaceList.Count; c++)
        //                argumentToPass += CharBackspaceList[c];
        //            Clear();
        //            ShowArgumentDescription();
        //            ForegroundColor = ConsoleColor.Green;
        //            WriteLine(argumentToPass);
        //            ResetColor();
        //        }
        //    }
        //}

        /// <summary>
        /// Checks is Enter key \r is pressed.
        /// </summary>
        //private static void CheckEnterIsPressed(List<char> CharEnterList, string argToProvide,
        //                                        Writer writer, HiThereWriter hiThere)
        //{

        //    if (CharEnterList.Contains('\r'))
        //    {

        //        ResetColor();
        //        foreach (char charItem in CharEnterList)
        //            argToProvide += $"{charItem}";
        //        switch (argToProvide)
        //        {
        //            case "p\r":
        //                ExplainProtected(writer, hiThere); break;
        //            //DescribeWriters(new Writer[] { writer, hiThere, }); break;
        //            case "pi\r":
        //                ExplainProtectedInternal(writer, hiThere);
        //                WriteLine(); break;
        //            case "pp\r":
        //                ExplainPrivateProtected(); break;
        //            case "exit\r": WriteLine($"{typeof(Program).Name} closed."); Exit(0); break;
        //            case "clear\r": Clear(); ShowArgumentDescription(); break;
        //            default:
        //                ForegroundColor = ConsoleColor.Red;
        //                WriteLine("Please provide \"p\", \"pi\" , \"pp\" or \"exit\" !!!");
        //                ResetColor();
        //                break;
        //        }
        //        CharEnterList.Clear();
        //    }
        //}

        #endregion

        private static void ChangeTitleColor(string title)
        {
            BackgroundColor = ConsoleColor.Blue;
            ForegroundColor = ConsoleColor.Yellow;
            WriteLine($"\r\n***{title.ToUpper()}***");
            ResetColor();
        }

        private static void ExplainProtected(Writer writer, HiThereWriter hiThere)
        {
            #region Explaining

           
            string description = "\r\n\r\n Protected means public to subclasses and private to everyone else.\r\n" +
                                  "These members can only be accessed and altered from inside the instances \r\n" +
                                  "of the subclass.\r\n";
            ChangeTitleColor("protected");
            WriteLine(description);

            #endregion


            hiThere.ChangeID(writer); // 1
            hiThere.ChangeID(hiThere); // 40

            WriteLine(writer);
            WriteLine(hiThere);

            /*
            LineWriter lineWriter = new LineWriter();
            //PROTECTED: no access to protected member 
            lineWriter.GetLinesWritten(writer);
            lineWriter.GetLinesWritten(hiThere);
            */
        }



        private static void ExplainProtectedInternal(Writer writer, HiThereWriter hiThere)
        {
            #region Explaining

            
            string description =
            "\r\n\r\n Writer contains two ID members, one marked protected and one protected internal.\r\n" +
            "HiThereWriter inherits from Writer and LineWriter is an independent class.\r\n" +
            "Both classes can change only the protected internal ID instance of a Writer type\r\nvia a Writer reference.\r\n" +
            "HiThereWriter.ChangeProtectedInternalID(Writer writer) and LineWriter.GetLinesWritten(Writer writer)\r\n" +
            "do this.\r\n\r\n" +
            "The HiThereWriter.ChangeID(Writer writer) method can only change the PROTECTED ID member but not\r\n" +
            "via a Writer reference but the ChangeProtectedInternalID(Writwer writer) does this.\r\nThis member can only be changed by subclasses that inherit from Writer.\r\n" +
            "The former does not have access to ID protected member via a Writer reference, \r\n" +
            "but only directly, while the latter has access to only protected internal ID member via a Writer reference.\r\n" +
            "\r\nLineWriter independent class can not directly access the PROTECTED ID\r\n" +
            "member only if it subclasses Writer base class.\r\n";

            ChangeTitleColor("protected internal");
            WriteLine(description);

            #endregion

            ForegroundColor = ConsoleColor.Cyan;
            WriteLine("\r\nRunning HiThereWriter.ChangeProtectedInternalID(Writer writer) method for\r\n" +
                      "changing protected internal member ID from subclass via a Writer qualifier" +
                      "...\r\n");
            ResetColor();

            hiThere.ChangeProtectedInternalID(writer); // 49
            hiThere.ChangeProtectedInternalID(hiThere); // 49

            WriteLine(writer);
            WriteLine(hiThere);

            ForegroundColor = ConsoleColor.Yellow;
            WriteLine("\r\nRunning LineWriter.GetLinesWritten(Writer writer) method for\r\n" +
                      "changing the same protected internal ID from another class via a Writer qualifier" +
                      "...\r\n");
            ResetColor();

            LineWriter lineWriter = new LineWriter();
            //PROTECTED INTERNL: 123 >> CHANGES THE PROTECTED INTERNAL ID MEMBER VIA A WRITER QUALIFIER.
            lineWriter.ChangeWriterProtIntID(writer); // 123
            lineWriter.ChangeWriterProtIntID(hiThere); // 123

            WriteLine(writer);
            WriteLine(hiThere);
        }


        private static void ExplainPrivateProtected()
        {
            string description = "\r\n\r\n HiTherePainter class inherits from Painter. Both are in Assembly1.\r\n" +
                                  "Any class from Assembly2 that inherits from Painter will not have\r\naccess " +
                                  "to PRIVATE PROTECTED members.\r\n" +
                                  "So, access is limited only tu subclasses from the same assembly for\r\n" +
                                  "PRIVATE PROTECTED members !!!";
            ChangeTitleColor("private protected");
            WriteLine(description);

            Painter Picasso = new Painter("The Old Guitarist", "Picasso");
            WriteLine(Picasso); // 1

            HiTherePainter VanGogh = new HiTherePainter("The Yellow House", "Van Gogh");
            WriteLine(VanGogh); // 1

            VanGogh.ChangeID(Picasso); // 1
            VanGogh.ChangeID(VanGogh); // 49

            WriteLine(Picasso);
            WriteLine(VanGogh);
        }

        private static void ShowArgumentDescription()
        {

            string message = "In order to see the differences between the protected access modifiers " +
                              "type one of the following\r\narguments p, pi, pp followed " +
                              "by the enter key.\r\n";
            ResetColor();
            WriteLine(message);

            string argDescription = "";

            string[,] arguments = new string[6, 2]
        {
                    { "[p]", " = protected, "},
                    { "[pi]", " = protected internal, "},
                    { "[pp]", " = private protected\r\n"},
                    { "[exit]", " = close the app, " },
                    { "[clear]", " = clear the console, " },
                    { "[help]", " = show again the access modifiers" },

        };
            for (int r = 0; r < 6; r++)
                for (int c = 0; c < 2; c++)
                    argDescription += $"{arguments[r, c]}";

            ForegroundColor = ConsoleColor.Green;
            WriteLine(argDescription);
            ResetColor();
        }

        private static void StartAccessModifiersApp()
        {

            #region Message

            string message = "Hello !!! This is ACCESS MODIFIER LESSON !!!\r\n\r\n" +
                            "A class's fields, properties, methods are called its MEMBERS.\r\n\r\n" +
                            "PUBLIC = ANY INSTANCE OF ANY OTHER CLASS CAN ACCESS ITS MEMBERS. \r\n" +
                            "         IT IS THE LEAST RESTRICTIVE ACCESS MODIFIER.\r\n\r\n" +
                            "PRIVATE = ANY MEMBER CAN ONLY BE ACCESSED FROM OTHER MEMBERS \r\n" +
                            "          INSIDE THAT CLASS OR OTHER INSTANCES OF THAT CLASS.\r\n\r\n" +
                            "PROTECTED = PUBLIC TO SUBCLASSES, PRIVATE TO EVERYONE ELSE.\r\n\r\n" +
                            "INTERNAL = PUBLIC ONLY TO OTHER CLASSES IN THE SAME ASSEMBLY.\r\n" +
                            "           ANY CLASS OR MEMBER OF THAT CLASS CAN ONLY BE ACCESSED FROM THE SAME " +
                            "ASSEMBLY.\r\n           THAT CLASS CAN NOT BE ACCESSED FROM ANOTHER PROGRAM OR ASSEMBLY.\r\n\r\n" +
              "PROTECTED INTERNAL = ADDS A NEW LEVEL OF ACCESSIBILITY FOR THE INTERBAL CLASSES OF AN ASSEMBLY" +
              "\r\n                     THAT DO NOT INHERIT FROM A BASE CLASS.\r\n" +
              "                     CLASSES FROM ANOTHER ASSEMBLY/PROGRAM CAN " +
              "ACCESS THE PROTECTED INTERNAL MEMBERS.\r\n" +
              "                     ONLY IF THEY INHERIT FROM THE CLASS THAT CONTAINS THOSE MEMBERS\r\n\r\n" +
              "PRIVATE PROTECTED  = members can be accessed by types derived from base class\r\n                     " +
                                    "BUT ONLY WITHIN ITS CONTAINING ASSEMBLY.\r\n" +
                                    "                     For instance, any derived class from Assembly2 " +
                                    "that tries to inherit\r\n" +
                                    "                     from Painter which is in Assembly1 will not " +
                                    "have access to PRIVATE PROTECTED MEMBERS.\r\n" +
                                    "                     Otherwise any class that it is in the same assembly as " +
                                    "Painter class and inherits from it\r\n                     " +
                                    "will have access to these kind of members.\r\n";

            #endregion
            Title = "Welcome to Access modifiers app !!!";
            Clear();
            WriteLine(message);
            ShowArgumentDescription();
        }
    }
}